<?php

/*
Plugin Name: Add Custom Tax / Insurance Fee in Checkout
Description: Add a custom tax or insurance fee based on the total product price.
Version: 1.0
Author: <a href="https://www.waapify.com">Najmi Hamdi</a>
*/


// Register a settings page in the admin panel
function custom_insurance_fee_settings_page() {
    add_menu_page(
        'Tax / Insurance Fee Settings',
        'Add Custom Tax / Insurance Fee',
        'manage_options',
        'insurance_fee_settings',
        'insurance_fee_settings_page'
    );
}
add_action('admin_menu', 'custom_insurance_fee_settings_page');

// Define and register plugin settings
function insurance_fee_settings_init() {
    register_setting('insurance_fee_settings_group', 'insurance_fee_percentage');
    register_setting('insurance_fee_settings_group', 'insurance_fee_name');
    register_setting('insurance_fee_settings_group', 'insurance_fee_fixed_rm'); // Add setting for fixed RM fee
}
add_action('admin_init', 'insurance_fee_settings_init');

// Callback function to render the settings page
function insurance_fee_settings_page() {
    // Check if the settings have been updated
    if (isset($_GET['settings-updated']) && $_GET['settings-updated']) {
        echo '<div id="message" class="updated fade"><p>Tax / Insurance fee settings have been updated.</p></div>';
    }
    ?>
    <div class="wrap">
        <h2>Tax / Insurance Fee Settings</h2>
        <form method="post" action="options.php">
            <?php settings_fields('insurance_fee_settings_group'); ?>
            <?php do_settings_sections('insurance_fee_settings_group'); ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Tax / Insurance Fee Name:</th>
                    <td><input type="text" name="insurance_fee_name" value="<?php echo esc_attr(get_option('insurance_fee_name')); ?>" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">Tax / Insurance Fee Percentage:</th>
                    <td><input type="number" step="0.01" min="0" name="insurance_fee_percentage" value="<?php echo esc_attr(get_option('insurance_fee_percentage')); ?>" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">Tax / Insurance Fee (Fixed in RM):</th>
                    <td><input type="number" step="0.01" min="0" name="insurance_fee_fixed_rm" value="<?php echo esc_attr(get_option('insurance_fee_fixed_rm')); ?>" /></td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

// Hook to add the tax or insurance fee
add_action('woocommerce_cart_calculate_fees', 'add_insurance_fee');

function add_insurance_fee() {
    global $woocommerce;
    
    // Get the tax or insurance fee name, percentage, and fixed RM fee from plugin settings
    $insurance_fee_name = get_option('insurance_fee_name', 'Tax / Insurance Fee');
    $insurance_fee_percentage = floatval(get_option('insurance_fee_percentage', 1.0));
    $insurance_fee_fixed_rm = floatval(get_option('insurance_fee_fixed_rm', 0.0));

    // Calculate the total product price in the cart
    $total_product_price = 0;
    
    foreach ( $woocommerce->cart->get_cart() as $cart_item_key => $cart_item ) {
        $total_product_price += $cart_item['data']->get_price() * $cart_item['quantity'];
    }
    
    // Calculate the insurance fee based on the percentage
    $percentage_fee = $total_product_price * ($insurance_fee_percentage / 100);
    
    // Calculate the insurance fee based on the fixed RM fee
    $fixed_fee = $insurance_fee_fixed_rm;
    
    // Add the insurance fee to the cart with the specified name
    if ($insurance_fee_percentage > 0 && $insurance_fee_fixed_rm > 0) {
        // If both percentage and fixed fee are specified, add both
        $woocommerce->cart->add_fee($insurance_fee_name . ' (Percentage)', $percentage_fee);
        $woocommerce->cart->add_fee($insurance_fee_name . ' (Fixed RM)', $fixed_fee);
    } elseif ($insurance_fee_percentage > 0) {
        // If only percentage is specified, add it
        $woocommerce->cart->add_fee($insurance_fee_name, $percentage_fee);
    } elseif ($insurance_fee_fixed_rm > 0) {
        // If only fixed RM fee is specified, add it
        $woocommerce->cart->add_fee($insurance_fee_name, $fixed_fee);
    }
}
?>